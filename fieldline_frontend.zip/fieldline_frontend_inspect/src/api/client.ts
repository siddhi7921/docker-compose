export const API_BASE_URL =
  import.meta.env.VITE_API_URL || '/api'

export async function apiFetch<T>(
path: string,
init: RequestInit = {}
): Promise<T> {
const response = await fetch(
`${API_BASE_URL}${path}`,
{
...init,
headers: {
'Content-Type': 'application/json',
...init.headers,
},
}
)

if (!response.ok) {
const message = await response.text().catch(() => '')

throw new Error(
  message || `Request failed (${response.status})`
)

}

// Handle responses with no content
if (response.status === 204) {
return undefined as T
}

return response.json() as Promise<T>
}
