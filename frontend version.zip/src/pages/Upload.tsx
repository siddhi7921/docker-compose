import { useState, useCallback } from 'react'
import { UploadCloud, FileText, FileSpreadsheet, Image, CheckCircle, AlertCircle, Loader2 } from 'lucide-react'
import { parseCSV, validateScheduleCSV } from '../utils/csvParser'
import type { UploadResult } from '../types'

export default function UploadPage() {
  const [scheduleFile, setScheduleFile] = useState<File | null>(null)
  const [fieldFiles, setFieldFiles] = useState<File[]>([])
  const [schedulePreview, setSchedulePreview] = useState<Record<string, string>[] | null>(null)
  const [scheduleError, setScheduleError] = useState<string | null>(null)
  const [processing, setProcessing] = useState(false)
  const [result, setResult] = useState<UploadResult | null>(null)

  const handleScheduleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    const file = e.dataTransfer.files[0]
    if (file && (file.name.endsWith('.csv') || file.name.endsWith('.xlsx'))) {
      processScheduleFile(file)
    }
  }, [])

  const processScheduleFile = (file: File) => {
    setScheduleFile(file)
    setScheduleError(null)
    setSchedulePreview(null)

    if (file.name.endsWith('.csv')) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const text = e.target?.result as string
        const rows = parseCSV(text)
        const validation = validateScheduleCSV(rows)
        if (validation.valid) {
          setSchedulePreview(rows.slice(0, 5))
        } else {
          setScheduleError(validation.errors.join(', '))
        }
      }
      reader.readAsText(file)
    }
  }

  const handleFieldDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    const files = Array.from(e.dataTransfer.files)
    setFieldFiles(prev => [...prev, ...files])
  }, [])

  const handleProcess = () => {
    setProcessing(true)
    setTimeout(() => {
      setProcessing(false)
      setResult({
        success: true,
        message: 'Processing complete',
        activitiesMatched: 4,
        reportsProcessed: fieldFiles.length || 3
      })
    }, 2500)
  }

  const removeFieldFile = (index: number) => {
    setFieldFiles(prev => prev.filter((_, i) => i !== index))
  }

  return (
    <div className="page upload-page">
      <div className="page-header">
        <h1 className="page-title">Upload Data</h1>
        <p className="page-subtitle">Upload your project schedule and field reports</p>
      </div>

      <div className="upload-grid">
        {/* Schedule Upload */}
        <div className="upload-section">
          <div className="upload-section-header">
            <FileSpreadsheet size={20} />
            <h2>Project Schedule</h2>
            <span className="upload-badge">Required</span>
          </div>

          <div
            className={`drop-zone ${scheduleFile ? 'has-file' : ''}`}
            onDragOver={e => e.preventDefault()}
            onDrop={handleScheduleDrop}
          >
            <input
              type="file"
              accept=".csv,.xlsx"
              onChange={e => e.target.files?.[0] && processScheduleFile(e.target.files[0])}
              id="schedule-input"
              hidden
            />
            <label htmlFor="schedule-input" className="drop-zone-content">
              <UploadCloud size={32} style={{ color: 'var(--kimi-color-text-quaternary)' }} />
              <p className="drop-text">Drop CSV or Excel file here</p>
              <p className="drop-sub">or click to browse</p>
            </label>
          </div>

          {scheduleFile && (
            <div className="file-info">
              <FileSpreadsheet size={18} />
              <span className="file-name">{scheduleFile.name}</span>
              <span className="file-size">{(scheduleFile.size / 1024).toFixed(1)} KB</span>
            </div>
          )}

          {scheduleError && (
            <div className="upload-error">
              <AlertCircle size={16} />
              <span>{scheduleError}</span>
            </div>
          )}

          {schedulePreview && (
            <div className="preview-table-wrapper">
              <p className="preview-label">Preview (first 5 rows)</p>
              <table className="preview-table">
                <thead>
                  <tr>
                    {Object.keys(schedulePreview[0]).map(h => (
                      <th key={h}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {schedulePreview.map((row, i) => (
                    <tr key={i}>
                      {Object.values(row).map((v, j) => (
                        <td key={j}>{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Field Reports Upload */}
        <div className="upload-section">
          <div className="upload-section-header">
            <FileText size={20} />
            <h2>Field Reports</h2>
            <span className="upload-badge upload-badge-optional">Optional</span>
          </div>

          <div
            className="drop-zone"
            onDragOver={e => e.preventDefault()}
            onDrop={handleFieldDrop}
          >
            <input
              type="file"
              accept=".pdf,.txt,.jpg,.jpeg,.png,.csv,.xlsx"
              multiple
              onChange={e => e.target.files && setFieldFiles(prev => [...prev, ...Array.from(e.target.files!)])}
              id="field-input"
              hidden
            />
            <label htmlFor="field-input" className="drop-zone-content">
              <UploadCloud size={32} style={{ color: 'var(--kimi-color-text-quaternary)' }} />
              <p className="drop-text">Drop reports, images, PDFs here</p>
              <p className="drop-sub">Supports PDF, TXT, JPG, PNG, CSV, Excel</p>
            </label>
          </div>

          {fieldFiles.length > 0 && (
            <div className="file-list">
              {fieldFiles.map((file, i) => {
                const Icon = file.type.startsWith('image/') ? Image :
                  file.name.endsWith('.pdf') ? FileText :
                  file.name.endsWith('.csv') || file.name.endsWith('.xlsx') ? FileSpreadsheet : FileText
                return (
                  <div key={i} className="file-list-item">
                    <Icon size={16} />
                    <span className="file-list-name">{file.name}</span>
                    <span className="file-list-size">{(file.size / 1024).toFixed(0)} KB</span>
                    <button
                      className="file-remove"
                      onClick={() => removeFieldFile(i)}
                    >
                      ×
                    </button>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>

      {/* Process Button */}
      <div className="process-section">
        <button
          className="process-btn"
          onClick={handleProcess}
          disabled={!scheduleFile || processing}
        >
          {processing ? (
            <>
              <Loader2 size={18} className="spin" />
              Processing with AI...
            </>
          ) : (
            <>
              <UploadCloud size={18} />
              Process & Link to Schedule
            </>
          )}
        </button>
      </div>

      {/* Result */}
      {result && (
        <div className="result-card">
          <div className="result-header">
            <CheckCircle size={20} style={{ color: 'var(--kimi-color-positive)' }} />
            <span className="result-title">{result.message}</span>
          </div>
          <div className="result-stats">
            <div className="result-stat">
              <span className="result-stat-value">{result.activitiesMatched}</span>
              <span className="result-stat-label">Activities matched</span>
            </div>
            <div className="result-stat">
              <span className="result-stat-value">{result.reportsProcessed}</span>
              <span className="result-stat-label">Reports processed</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
