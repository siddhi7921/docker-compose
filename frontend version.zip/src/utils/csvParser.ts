export const parseCSV = (content: string): Record<string, string>[] => {
  const lines = content.trim().split('\n')
  if (lines.length < 2) return []

  const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''))
  const rows: Record<string, string>[] = []

  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim().replace(/^"|"$/g, ''))
    const row: Record<string, string> = {}
    headers.forEach((header, index) => {
      row[header] = values[index] || ''
    })
    rows.push(row)
  }

  return rows
}

export const validateScheduleCSV = (rows: Record<string, string>[]): { valid: boolean; errors: string[] } => {
  const errors: string[] = []
  const required = ['Activity ID', 'Activity Name', 'Location', 'Planned Start', 'Planned End']

  if (rows.length === 0) {
    errors.push('CSV file is empty')
    return { valid: false, errors }
  }

  const headers = Object.keys(rows[0])
  required.forEach(field => {
    if (!headers.some(h => h.toLowerCase().includes(field.toLowerCase()))) {
      errors.push(`Missing required field: ${field}`)
    }
  })

  return { valid: errors.length === 0, errors }
}
