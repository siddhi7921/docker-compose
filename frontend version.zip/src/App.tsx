import { Routes, Route } from 'react-router-dom'
import Header from './components/Header'
import Dashboard from './pages/Dashboard'
import UploadPage from './pages/Upload'
import ActivityDetail from './pages/ActivityDetail'

export default function App() {
  return (
    <div className="app">
      <Header />
      <main className="main">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/upload" element={<UploadPage />} />
          <Route path="/activity/:id" element={<ActivityDetail />} />
        </Routes>
      </main>
    </div>
  )
}
