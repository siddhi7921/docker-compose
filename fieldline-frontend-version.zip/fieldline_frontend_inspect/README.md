# FieldLine — Front-End Application

Intelligent Data Capture & Schedule-Linking Layer for Infrastructure Project Management.

## Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Project Structure

```
src/
  components/
    ActivityCard.tsx      # Activity list item with progress & confidence
    ConfidenceBar.tsx     # AI match confidence indicator
    EvidenceViewer.tsx    # Source evidence display
    Header.tsx            # Top navigation bar
    ProgressBar.tsx       # Actual vs planned progress bar
    StatusBadge.tsx       # Status pill (ahead/on-track/at-risk/delayed/completed)
  pages/
    Dashboard.tsx         # Main project dashboard with stats, filters, activity list
    Upload.tsx            # Schedule & field report upload with AI processing
    ActivityDetail.tsx    # Single activity view with evidence traceability
  types/
    index.ts              # TypeScript interfaces
  utils/
    csvParser.ts          # CSV parsing & validation
    mockData.ts           # Demo data (6 activities with evidence)
  App.tsx                 # Router setup
  main.tsx                # Entry point
  index.css               # Complete stylesheet (light/dark mode)
```

## Key Features

### 1. Dashboard
- **Stats cards**: Overall progress, total activities, delayed count, ahead count
- **Alert banner**: Highlights delayed activities automatically
- **Filter bar**: Filter by status (all/ahead/on-track/at-risk/delayed/completed)
- **Search**: Find activities by name, ID, or location
- **Activity cards**: Show name, ID, location, status badge, progress bar, confidence bar, evidence count

### 2. Upload
- **Schedule upload**: Drag & drop CSV/Excel, live preview first 5 rows, validation
- **Field reports upload**: Multi-file drop for PDF, TXT, JPG, PNG, CSV, Excel
- **AI processing**: Simulated processing with loading state
- **Result card**: Shows matched activities and processed reports count

### 3. Activity Detail
- **Progress comparison**: Large progress bar showing actual vs planned
- **Variance indicator**: Shows if ahead or behind plan with color coding
- **Schedule dates**: Planned start and end dates
- **Quantities**: Planned, actual, and remaining quantities
- **AI confidence**: Confidence bar with explanatory note
- **Evidence viewer**: Lists all source evidence with excerpts, timestamps, and page numbers

## Design Decisions

- **No external UI library**: Pure CSS for full control and lightweight bundle
- **Lucide React**: Clean, consistent icons
- **CSS custom properties**: Full light/dark mode support via `prefers-color-scheme`
- **Responsive**: Mobile-first with breakpoints at 640px, 768px, 900px
- **Accessible**: Proper focus states, semantic HTML, keyboard navigation
- **Mock data**: 6 realistic activities with linked evidence for demo purposes

## Demo Data Highlights

| Activity | Status | Actual | Planned | Confidence |
|----------|--------|--------|---------|------------|
| Excavation — Section C | Completed | 100% | 100% | 95% |
| Foundation Work — Block B | Delayed | 65% | 80% | 88% |
| Reinforcement — Block B | At Risk | 0% | 30% | — |
| Install Pump P-104 | Delayed | 40% | 100% | 92% |
| Pipeline Welding — Section A | Ahead | 110% | 95% | 90% |

## For SIH Presentation

The dashboard is your **killer demo screen**. Walk through:
1. Point to the delayed alert banner
2. Click an activity card → show the detail page
3. Highlight the "Source Evidence" section — this is your traceability differentiator
4. Go to Upload → drag a CSV → show the preview table
5. Click Process → show the result card

This proves the full "planning-to-execution bridge" in under 2 minutes.
