const scheduleExt = ['csv','xlsx','xls']
const evidenceExt = ['pdf','txt','jpg','jpeg','png','csv','xlsx','xls','doc','docx']
const MAX_FILE_SIZE = 25 * 1024 * 1024
const extension = (file: File) => file.name.split('.').pop()?.toLowerCase() ?? ''
export const validateScheduleFile = (file: File) => {
  if (!scheduleExt.includes(extension(file))) return 'Schedule must be CSV, XLS or XLSX.'
  if (file.size > MAX_FILE_SIZE) return 'Schedule file must be smaller than 25 MB.'
  return null
}
export const validateEvidenceFiles = (files: File[]) => {
  const errors: string[] = []
  if (files.length > 20) errors.push('Upload a maximum of 20 evidence files at once.')
  files.forEach(f => { if (!evidenceExt.includes(extension(f))) errors.push(`${f.name}: unsupported format`); if (f.size > MAX_FILE_SIZE) errors.push(`${f.name}: exceeds 25 MB`) })
  return errors
}
