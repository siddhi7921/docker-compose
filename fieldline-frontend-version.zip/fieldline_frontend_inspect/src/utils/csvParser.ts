import Papa from 'papaparse'

export const parseCSV = (content: string): Record<string, string>[] => {
  const result = Papa.parse<Record<string, string>>(content, { header: true, skipEmptyLines: 'greedy', transformHeader: h => h.trim() })
  return (result.data || []).filter(row => Object.values(row).some(v => String(v ?? '').trim() !== ''))
}

export const validateScheduleCSV = (rows: Record<string, string>[]): { valid: boolean; errors: string[] } => {
  const errors: string[] = []
  const required = ['Activity ID', 'Activity Name', 'Location', 'Planned Start', 'Planned End']
  if (!rows.length) return { valid: false, errors: ['Schedule file is empty or unreadable'] }
  const headers = Object.keys(rows[0])
  required.forEach(field => {
    if (!headers.some(h => h.toLowerCase().replace(/[_-]/g, ' ').includes(field.toLowerCase()))) errors.push(`Missing required field: ${field}`)
  })
  return { valid: errors.length === 0, errors }
}
