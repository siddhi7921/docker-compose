import * as XLSX from 'xlsx'
import { parseCSV, validateScheduleCSV } from './csvParser'

export async function parseScheduleFile(file: File) {
  const ext = file.name.split('.').pop()?.toLowerCase()
  let rows: Record<string, string>[]
  if (ext === 'csv') rows = parseCSV(await file.text())
  else if (ext === 'xlsx' || ext === 'xls') {
    const workbook = XLSX.read(await file.arrayBuffer(), { type: 'array' })
    const sheet = workbook.Sheets[workbook.SheetNames[0]]
    rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' }).map(row => Object.fromEntries(Object.entries(row).map(([k,v]) => [String(k).trim(), String(v ?? '')])))
  } else throw new Error('Unsupported schedule format. Use CSV, XLS or XLSX.')
  return { rows, validation: validateScheduleCSV(rows) }
}
