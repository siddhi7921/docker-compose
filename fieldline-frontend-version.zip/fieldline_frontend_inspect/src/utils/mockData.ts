import type { Activity, FieldReport } from '../types'

export const mockActivities: Activity[] = [
  {
    id: 'act-001',
    activityId: 'EXC-C-001',
    name: 'Excavation — Section C',
    location: 'Block C, Pipeline Route',
    wbs: '1.2.3',
    plannedStart: '2026-08-20',
    plannedEnd: '2026-08-22',
    plannedQuantity: 500,
    actualQuantity: 500,
    actualProgress: 100,
    plannedProgress: 100,
    status: 'completed',
    confidence: 95,
    evidence: [
      {
        id: 'ev-001',
        type: 'text',
        source: 'Site Diary — Aug 22',
        excerpt: 'Excavation for section C completed today. Total volume: 500 cubic metres.',
        timestamp: '2026-08-22T16:30:00Z'
      }
    ],
    fieldReports: []
  },
  {
    id: 'act-002',
    activityId: 'FDN-B-023',
    name: 'Foundation Work — Block B',
    location: 'Block B, Refinery Base',
    wbs: '1.3.1',
    plannedStart: '2026-08-23',
    plannedEnd: '2026-08-26',
    plannedQuantity: 120,
    actualQuantity: 78,
    actualProgress: 65,
    plannedProgress: 80,
    status: 'delayed',
    confidence: 88,
    evidence: [
      {
        id: 'ev-002',
        type: 'text',
        source: 'Supervisor Report — Aug 25',
        excerpt: 'Foundation work at Block B. 120 cubic metres concrete poured. Reinforcement still pending.',
        timestamp: '2026-08-25T14:00:00Z'
      },
      {
        id: 'ev-003',
        type: 'pdf',
        source: 'Daily Progress Report.pdf',
        excerpt: 'Page 3: Foundation pour completed for Block B. Quantity: 78/120 m³.',
        timestamp: '2026-08-25T18:00:00Z',
        pageNumber: 3
      }
    ],
    fieldReports: []
  },
  {
    id: 'act-003',
    activityId: 'RNF-B-015',
    name: 'Reinforcement — Block B',
    location: 'Block B, Refinery Base',
    wbs: '1.3.2',
    plannedStart: '2026-08-26',
    plannedEnd: '2026-08-28',
    plannedQuantity: 200,
    actualQuantity: 0,
    actualProgress: 0,
    plannedProgress: 30,
    status: 'at-risk',
    confidence: 0,
    evidence: [],
    fieldReports: []
  },
  {
    id: 'act-004',
    activityId: 'CNP-B-008',
    name: 'Concrete Pouring — Block B',
    location: 'Block B, Refinery Base',
    wbs: '1.3.3',
    plannedStart: '2026-08-29',
    plannedEnd: '2026-08-31',
    plannedQuantity: 300,
    actualQuantity: 0,
    actualProgress: 0,
    plannedProgress: 0,
    status: 'on-track',
    confidence: 0,
    evidence: [],
    fieldReports: []
  },
  {
    id: 'act-005',
    activityId: 'MECH-204',
    name: 'Install Pump P-104',
    location: 'Pump House, Unit 2',
    wbs: '2.1.4',
    plannedStart: '2026-08-15',
    plannedEnd: '2026-08-20',
    plannedQuantity: 1,
    actualQuantity: 0.4,
    actualProgress: 40,
    plannedProgress: 100,
    status: 'delayed',
    confidence: 92,
    evidence: [
      {
        id: 'ev-004',
        type: 'text',
        source: 'Mechanical Supervisor — Aug 19',
        excerpt: 'Pump P104 installation started yesterday. Base plate installed, motor alignment pending.',
        timestamp: '2026-08-19T09:15:00Z'
      }
    ],
    fieldReports: []
  },
  {
    id: 'act-006',
    activityId: 'PIP-301',
    name: 'Pipeline Welding — Section A',
    location: 'Section A, KM 12-15',
    wbs: '3.2.1',
    plannedStart: '2026-08-18',
    plannedEnd: '2026-08-24',
    plannedQuantity: 150,
    actualQuantity: 165,
    actualProgress: 110,
    plannedProgress: 95,
    status: 'ahead',
    confidence: 90,
    evidence: [
      {
        id: 'ev-005',
        type: 'image',
        source: 'Site Photo — Aug 23.jpg',
        excerpt: 'Welding joints completed at KM 14.2. Total: 165 joints.',
        timestamp: '2026-08-23T11:00:00Z'
      }
    ],
    fieldReports: []
  }
]

export const mockFieldReports: FieldReport[] = [
  {
    id: 'fr-001',
    source: 'Site Diary — Aug 22.txt',
    type: 'text',
    uploadDate: '2026-08-22',
    status: 'processed',
    extractedActivities: 1
  },
  {
    id: 'fr-002',
    source: 'Supervisor Report — Aug 25.txt',
    type: 'text',
    uploadDate: '2026-08-25',
    status: 'processed',
    extractedActivities: 2
  },
  {
    id: 'fr-003',
    source: 'Daily Progress Report.pdf',
    type: 'pdf',
    uploadDate: '2026-08-25',
    status: 'processed',
    extractedActivities: 3
  },
  {
    id: 'fr-004',
    source: 'Mechanical Supervisor — Aug 19.txt',
    type: 'text',
    uploadDate: '2026-08-19',
    status: 'processed',
    extractedActivities: 1
  },
  {
    id: 'fr-005',
    source: 'Site Photo — Aug 23.jpg',
    type: 'image',
    uploadDate: '2026-08-23',
    status: 'processed',
    extractedActivities: 1
  }
]

export const getStatusCounts = (activities: Activity[]) => {
  return {
    ahead: activities.filter(a => a.status === 'ahead').length,
    'on-track': activities.filter(a => a.status === 'on-track').length,
    'at-risk': activities.filter(a => a.status === 'at-risk').length,
    delayed: activities.filter(a => a.status === 'delayed').length,
    completed: activities.filter(a => a.status === 'completed').length,
  }
}

export const getOverallProgress = (activities: Activity[]) => {
  const totalPlanned = activities.reduce((sum, a) => sum + a.plannedProgress, 0)
  const totalActual = activities.reduce((sum, a) => sum + a.actualProgress, 0)
  return {
    planned: Math.round(totalPlanned / activities.length),
    actual: Math.round(totalActual / activities.length)
  }
}
