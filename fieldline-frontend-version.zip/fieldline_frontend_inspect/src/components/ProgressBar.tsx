interface Props {
  actual: number
  planned: number
  showLabels?: boolean
  size?: 'sm' | 'md' | 'lg'
}

export default function ProgressBar({ actual, planned, showLabels = true, size = 'md' }: Props) {
  const heights = { sm: 6, md: 10, lg: 14 }
  const height = heights[size]

  return (
    <div className="progress-bar-wrapper">
      {showLabels && (
        <div className="progress-labels">
          <span className="progress-label">
            <span className="progress-dot" style={{ backgroundColor: 'var(--kimi-chart-1)' }} />
            Actual: {actual}%
          </span>
          <span className="progress-label">
            <span className="progress-dot" style={{ backgroundColor: 'var(--kimi-color-text-quaternary)' }} />
            Planned: {planned}%
          </span>
        </div>
      )}
      <div className="progress-track" style={{ height }}>
        <div
          className="progress-planned"
          style={{ width: `${planned}%`, height: '100%' }}
        />
        <div
          className="progress-actual"
          style={{ width: `${actual}%`, height: '100%' }}
        />
      </div>
    </div>
  )
}
