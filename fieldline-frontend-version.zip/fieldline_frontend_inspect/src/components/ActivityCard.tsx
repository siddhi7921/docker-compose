import { ChevronRight, MapPin } from 'lucide-react'
import { Link } from 'react-router-dom'
import type { Activity } from '../types'
import StatusBadge from './StatusBadge'
import ProgressBar from './ProgressBar'
import ConfidenceBar from './ConfidenceBar'

interface Props {
  activity: Activity
}

export default function ActivityCard({ activity }: Props) {
  return (
    <Link to={`/activity/${activity.id}`} className="activity-card">
      <div className="activity-card-header">
        <div className="activity-card-title-row">
          <div>
            <h3 className="activity-name">{activity.name}</h3>
            <div className="activity-meta">
              <span className="activity-id">{activity.activityId}</span>
              <span className="activity-wbs">WBS {activity.wbs}</span>
            </div>
          </div>
          <StatusBadge status={activity.status} />
        </div>
        <div className="activity-location">
          <MapPin size={14} />
          <span>{activity.location}</span>
        </div>
      </div>

      <ProgressBar
        actual={activity.actualProgress}
        planned={activity.plannedProgress}
        size="sm"
      />

      {activity.confidence > 0 && (
        <ConfidenceBar confidence={activity.confidence} size="sm" />
      )}

      <div className="activity-card-footer">
        <span className="evidence-count">
          {activity.evidence.length} evidence item{activity.evidence.length !== 1 ? 's' : ''}
        </span>
        <ChevronRight size={16} style={{ color: 'var(--kimi-color-text-quaternary)' }} />
      </div>
    </Link>
  )
}
