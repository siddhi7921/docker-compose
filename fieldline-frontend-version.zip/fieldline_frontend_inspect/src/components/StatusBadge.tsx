import type { ProjectStatus } from '../types'

const statusConfig: Record<ProjectStatus, { label: string; className: string }> = {
  'ahead': { label: 'Ahead', className: 'status-ahead' },
  'on-track': { label: 'On Track', className: 'status-ontime' },
  'at-risk': { label: 'At Risk', className: 'status-atrisk' },
  'delayed': { label: 'Delayed', className: 'status-delayed' },
  'completed': { label: 'Completed', className: 'status-ahead' },
}

interface Props {
  status: ProjectStatus
  size?: 'sm' | 'md'
}

export default function StatusBadge({ status, size = 'md' }: Props) {
  const config = statusConfig[status]
  const sizeClass = size === 'sm' ? 'pill-sm' : 'pill-md'

  return (
    <span className={`status-pill ${config.className} ${sizeClass}`}>
      {config.label}
    </span>
  )
}
