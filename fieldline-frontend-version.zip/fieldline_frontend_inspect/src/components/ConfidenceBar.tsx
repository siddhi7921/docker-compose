interface Props {
  confidence: number
  size?: 'sm' | 'md'
}

export default function ConfidenceBar({ confidence, size = 'md' }: Props) {
  const getColor = () => {
    if (confidence >= 90) return 'var(--kimi-color-positive)'
    if (confidence >= 70) return 'var(--kimi-chart-1)'
    if (confidence >= 50) return 'var(--kimi-color-warning)'
    return 'var(--kimi-color-danger)'
  }

  const height = size === 'sm' ? 4 : 6

  return (
    <div className="confidence-bar">
      <div className="confidence-label">
        <span className="confidence-text">Confidence</span>
        <span className="confidence-value" style={{ color: getColor() }}>
          {confidence}%
        </span>
      </div>
      <div className="confidence-track" style={{ height }}>
        <div
          className="confidence-fill"
          style={{
            width: `${confidence}%`,
            backgroundColor: getColor(),
            height: '100%',
            borderRadius: height / 2,
            transition: 'width 0.4s ease-out'
          }}
        />
      </div>
    </div>
  )
}
