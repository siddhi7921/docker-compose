import { FileText, Image, FileSpreadsheet, File } from 'lucide-react'
import type { Evidence } from '../types'

const typeIcons = {
  pdf: File,
  image: Image,
  excel: FileSpreadsheet,
  text: FileText,
}

interface Props {
  evidence: Evidence[]
}

export default function EvidenceViewer({ evidence }: Props) {
  if (evidence.length === 0) {
    return (
      <div className="evidence-empty">
        <FileText size={32} style={{ color: 'var(--kimi-color-text-quaternary)' }} />
        <p>No evidence linked yet</p>
      </div>
    )
  }

  return (
    <div className="evidence-list">
      {evidence.map(item => {
        const Icon = typeIcons[item.type]
        return (
          <div key={item.id} className="evidence-card">
            <div className="evidence-header">
              <Icon size={18} style={{ color: 'var(--kimi-color-text-secondary)' }} />
              <span className="evidence-source">{item.source}</span>
              {item.pageNumber && (
                <span className="evidence-page">Page {item.pageNumber}</span>
              )}
            </div>
            <p className="evidence-excerpt">"{item.excerpt}"</p>
            <span className="evidence-time">
              {new Date(item.timestamp).toLocaleDateString('en-IN', {
                day: 'numeric',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}
            </span>
          </div>
        )
      })}
    </div>
  )
}
