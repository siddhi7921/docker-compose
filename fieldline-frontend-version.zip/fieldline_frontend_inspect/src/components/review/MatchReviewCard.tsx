import { CheckCircle2, Pencil, XCircle } from 'lucide-react'
export default function MatchReviewCard({ onConfirm }: { onConfirm: () => void }) {
  return <section className="review-card"><div className="review-card-title"><CheckCircle2 size={20}/><div><h2>Best Schedule Match</h2><p>AI found the most likely planned activity.</p></div></div><div className="match-id">MECH-204</div><h3>Install Pump P-104</h3><div className="confidence-large"><span>Confidence</span><strong>94%</strong></div><div className="review-actions"><button className="primary-action" onClick={onConfirm}><CheckCircle2 size={16}/> Confirm Match</button><button className="secondary-action"><Pencil size={16}/> Edit</button><button className="danger-action"><XCircle size={16}/> Reject</button></div></section>
}
