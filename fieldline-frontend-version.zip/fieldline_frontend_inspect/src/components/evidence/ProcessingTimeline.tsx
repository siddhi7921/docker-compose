const stages = ['Uploaded', 'Extracting', 'AI Analysis', 'Schedule Matching', 'Progress Calculation', 'Completed']
export default function ProcessingTimeline({ current }: { current: number }) {
  return <div className="processing-timeline">{stages.map((stage, index) => <div key={stage} className={`timeline-step ${index <= current ? 'active' : ''}`}><div className="timeline-dot">{index < current ? '✓' : index + 1}</div><span>{stage}</span></div>)}</div>
}
