import { useState } from 'react'
import { FileText, Sparkles, CheckCircle2 } from 'lucide-react'
import MatchReviewCard from '../components/review/MatchReviewCard'

export default function AIReview() {
  const [confirmed, setConfirmed] = useState(false)
  return <div className="page review-page"><div className="page-header"><h1 className="page-title">AI Extraction & Schedule Review</h1><p className="page-subtitle">Review AI-extracted field information before updating verified project progress.</p></div><div className="review-grid"><section className="review-card"><div className="review-card-title"><FileText size={20}/><div><h2>Original Field Report</h2><p>Supervisor Report — Aug 19</p></div></div><blockquote>“Pump P104 installation started yesterday. Base plate installed, motor alignment pending.”</blockquote></section><section className="review-card"><div className="review-card-title"><Sparkles size={20}/><div><h2>AI Extracted Information</h2><p>Structured from the source evidence.</p></div></div><dl className="extracted-list"><div><dt>Work</dt><dd>Pump P-104 Installation</dd></div><div><dt>Status</dt><dd>In Progress</dd></div><div><dt>Completed</dt><dd>Base plate installed</dd></div><div><dt>Pending</dt><dd>Motor alignment</dd></div><div><dt>Estimated progress</dt><dd>40%</dd></div></dl></section><MatchReviewCard onConfirm={() => setConfirmed(true)}/></div>{confirmed && <div className="alert-banner alert-success"><CheckCircle2 size={18}/><strong>Match confirmed.</strong><span> Project data can now be updated through the backend.</span></div>}</div>
}
