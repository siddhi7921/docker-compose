import { useMemo, useState } from 'react'
import {
  TrendingUp, TrendingDown, AlertTriangle, CheckCircle,
  Clock, Activity, Filter, Search
} from 'lucide-react'
import ActivityCard from '../components/ActivityCard'
import ProgressBar from '../components/ProgressBar'
import { mockActivities, getStatusCounts, getOverallProgress } from '../utils/mockData'
import type { ProjectStatus } from '../types'

const statusFilters: { value: ProjectStatus | 'all'; label: string; icon: typeof CheckCircle }[] = [
  { value: 'all', label: 'All', icon: Activity },
  { value: 'ahead', label: 'Ahead', icon: TrendingUp },
  { value: 'on-track', label: 'On Track', icon: CheckCircle },
  { value: 'at-risk', label: 'At Risk', icon: AlertTriangle },
  { value: 'delayed', label: 'Delayed', icon: TrendingDown },
  { value: 'completed', label: 'Completed', icon: CheckCircle },
]

export default function Dashboard() {
  const [filter, setFilter] = useState<ProjectStatus | 'all'>('all')
  const [search, setSearch] = useState('')

  const counts = useMemo(() => getStatusCounts(mockActivities), [])
  const overall = useMemo(() => getOverallProgress(mockActivities), [])

  const filtered = useMemo(() => {
    return mockActivities.filter(a => {
      const matchesFilter = filter === 'all' || a.status === filter
      const matchesSearch = search === '' ||
        a.name.toLowerCase().includes(search.toLowerCase()) ||
        a.activityId.toLowerCase().includes(search.toLowerCase()) ||
        a.location.toLowerCase().includes(search.toLowerCase())
      return matchesFilter && matchesSearch
    })
  }, [filter, search])

  const delayedActivities = mockActivities.filter(a => a.status === 'delayed')

  return (
    <div className="page dashboard-page">
      <div className="page-header">
        <h1 className="page-title">Project Dashboard</h1>
        <p className="page-subtitle">Real-time progress tracking — Planning to Execution Bridge</p>
      </div>

      {/* Stats Row */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-label">Overall Progress</span>
            <Clock size={18} style={{ color: 'var(--kimi-color-text-quaternary)' }} />
          </div>
          <div className="stat-value">{overall.actual}%</div>
          <div className="stat-sub">Planned: {overall.planned}%</div>
          <ProgressBar actual={overall.actual} planned={overall.planned} showLabels={false} size="sm" />
        </div>

        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-label">Activities</span>
            <Activity size={18} style={{ color: 'var(--kimi-color-text-quaternary)' }} />
          </div>
          <div className="stat-value">{mockActivities.length}</div>
          <div className="stat-sub">{counts.completed} completed</div>
        </div>

        <div className="stat-card stat-card-danger">
          <div className="stat-header">
            <span className="stat-label">Delayed</span>
            <TrendingDown size={18} style={{ color: 'var(--kimi-color-danger)' }} />
          </div>
          <div className="stat-value" style={{ color: 'var(--kimi-color-danger)' }}>
            {counts.delayed}
          </div>
          <div className="stat-sub">{counts['at-risk']} at risk</div>
        </div>

        <div className="stat-card stat-card-success">
          <div className="stat-header">
            <span className="stat-label">Ahead</span>
            <TrendingUp size={18} style={{ color: 'var(--kimi-color-positive)' }} />
          </div>
          <div className="stat-value" style={{ color: 'var(--kimi-color-positive)' }}>
            {counts.ahead}
          </div>
          <div className="stat-sub">{counts['on-track']} on track</div>
        </div>
      </div>

      {/* Delayed Alert */}
      {delayedActivities.length > 0 && (
        <div className="alert-banner alert-danger">
          <AlertTriangle size={18} />
          <div>
            <strong>{delayedActivities.length} {delayedActivities.length === 1 ? 'activity' : 'activities'} delayed</strong>
            <span> — {delayedActivities.map(a => a.name).join(', ')}</span>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="filter-bar">
        <div className="filter-group">
          <Filter size={16} style={{ color: 'var(--kimi-color-text-quaternary)' }} />
          {statusFilters.map(f => {
            const Icon = f.icon
            const active = filter === f.value
            return (
              <button
                key={f.value}
                className={`filter-btn ${active ? 'active' : ''}`}
                onClick={() => setFilter(f.value)}
              >
                <Icon size={14} />
                <span>{f.label}</span>
                {f.value !== 'all' && (
                  <span className="filter-count">{counts[f.value]}</span>
                )}
              </button>
            )
          })}
        </div>
        <div className="search-box">
          <Search size={16} />
          <input
            type="text"
            placeholder="Search activities..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
      </div>

      {/* Activity List */}
      <div className="activity-list">
        {filtered.length === 0 ? (
          <div className="empty-state">
            <Search size={40} style={{ color: 'var(--kimi-color-text-quaternary)' }} />
            <p>No activities match your filters</p>
          </div>
        ) : (
          filtered.map(activity => (
            <ActivityCard key={activity.id} activity={activity} />
          ))
        )}
      </div>
    </div>
  )
}
