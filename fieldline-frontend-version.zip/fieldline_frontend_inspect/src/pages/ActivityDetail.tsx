import { useParams, Link } from 'react-router-dom'
import { ArrowLeft, MapPin, Calendar, Hash, Layers } from 'lucide-react'
import StatusBadge from '../components/StatusBadge'
import ProgressBar from '../components/ProgressBar'
import ConfidenceBar from '../components/ConfidenceBar'
import EvidenceViewer from '../components/EvidenceViewer'
import { mockActivities } from '../utils/mockData'

export default function ActivityDetail() {
  const { id } = useParams<{ id: string }>()
  const activity = mockActivities.find(a => a.id === id)

  if (!activity) {
    return (
      <div className="page">
        <div className="empty-state">
          <p>Activity not found</p>
          <Link to="/" className="back-link">Back to dashboard</Link>
        </div>
      </div>
    )
  }

  const variance = activity.actualProgress - activity.plannedProgress
  const varianceText = variance > 0
    ? `+${variance}% ahead of plan`
    : variance < 0
    ? `${variance}% behind plan`
    : 'On plan'

  const varianceColor = variance > 0
    ? 'var(--kimi-color-positive)'
    : variance < 0
    ? 'var(--kimi-color-danger)'
    : 'var(--kimi-color-text-secondary)'

  return (
    <div className="page detail-page">
      <Link to="/" className="back-link">
        <ArrowLeft size={16} />
        Back to dashboard
      </Link>

      <div className="detail-header">
        <div className="detail-title-row">
          <div>
            <h1 className="detail-title">{activity.name}</h1>
            <div className="detail-meta">
              <span className="detail-meta-item">
                <Hash size={14} />
                {activity.activityId}
              </span>
              <span className="detail-meta-item">
                <Layers size={14} />
                WBS {activity.wbs}
              </span>
              <span className="detail-meta-item">
                <MapPin size={14} />
                {activity.location}
              </span>
            </div>
          </div>
          <StatusBadge status={activity.status} />
        </div>
      </div>

      <div className="detail-grid">
        {/* Progress Card */}
        <div className="detail-card">
          <h2 className="detail-card-title">Progress</h2>
          <ProgressBar
            actual={activity.actualProgress}
            planned={activity.plannedProgress}
            size="lg"
          />
          <div className="detail-variance" style={{ color: varianceColor }}>
            {varianceText}
          </div>
        </div>

        {/* Dates Card */}
        <div className="detail-card">
          <h2 className="detail-card-title">Schedule</h2>
          <div className="detail-dates">
            <div className="detail-date-row">
              <Calendar size={16} />
              <div>
                <span className="detail-date-label">Planned start</span>
                <span className="detail-date-value">
                  {new Date(activity.plannedStart).toLocaleDateString('en-IN', {
                    day: 'numeric', month: 'long', year: 'numeric'
                  })}
                </span>
              </div>
            </div>
            <div className="detail-date-row">
              <Calendar size={16} />
              <div>
                <span className="detail-date-label">Planned end</span>
                <span className="detail-date-value">
                  {new Date(activity.plannedEnd).toLocaleDateString('en-IN', {
                    day: 'numeric', month: 'long', year: 'numeric'
                  })}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Quantity Card */}
        <div className="detail-card">
          <h2 className="detail-card-title">Quantity</h2>
          <div className="detail-quantities">
            <div className="detail-quantity">
              <span className="detail-quantity-label">Planned</span>
              <span className="detail-quantity-value">{activity.plannedQuantity}</span>
            </div>
            <div className="detail-quantity">
              <span className="detail-quantity-label">Actual</span>
              <span className="detail-quantity-value">{activity.actualQuantity}</span>
            </div>
            <div className="detail-quantity">
              <span className="detail-quantity-label">Remaining</span>
              <span className="detail-quantity-value">
                {Math.max(0, activity.plannedQuantity - activity.actualQuantity)}
              </span>
            </div>
          </div>
        </div>

        {/* Confidence Card */}
        {activity.confidence > 0 && (
          <div className="detail-card">
            <h2 className="detail-card-title">AI Match Confidence</h2>
            <ConfidenceBar confidence={activity.confidence} size="md" />
            <p className="detail-confidence-note">
              This activity was automatically linked to field reports with the confidence shown above.
              Review the evidence below to verify.
            </p>
          </div>
        )}
      </div>

      {/* Evidence Section */}
      <div className="detail-evidence-section">
        <h2 className="detail-card-title">Source Evidence</h2>
        <p className="detail-evidence-subtitle">
          Every project status is traceable back to its original field evidence
        </p>
        <EvidenceViewer evidence={activity.evidence} />
      </div>
    </div>
  )
}
