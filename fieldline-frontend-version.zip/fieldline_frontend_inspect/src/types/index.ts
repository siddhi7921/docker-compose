export interface Activity {
  id: string
  activityId: string
  name: string
  location: string
  wbs: string
  plannedStart: string
  plannedEnd: string
  plannedQuantity: number
  actualQuantity: number
  actualProgress: number
  plannedProgress: number
  status: 'ahead' | 'on-track' | 'at-risk' | 'delayed' | 'completed'
  confidence: number
  evidence: Evidence[]
  fieldReports: FieldReport[]
}

export interface Evidence {
  id: string
  type: 'pdf' | 'image' | 'text' | 'excel'
  source: string
  excerpt: string
  timestamp: string
  pageNumber?: number
}

export interface FieldReport {
  id: string
  source: string
  type: 'pdf' | 'image' | 'text' | 'excel'
  uploadDate: string
  status: 'processed' | 'processing' | 'failed'
  extractedActivities: number
}

export interface UploadResult {
  success: boolean
  message: string
  activitiesMatched: number
  reportsProcessed: number
}

export type ProjectStatus = 'ahead' | 'on-track' | 'at-risk' | 'delayed' | 'completed'
